package com.example.BankApp;

import java.util.Optional;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;


@Controller
public class EmployeeRestController {

    private final EmployeeService service;

    public EmployeeRestController(EmployeeService service) {
        this.service = service;
    }

    // CREATE EMPLOYEE PAGE
    @GetMapping("/employees/create")
    public String createPage() {
        return "create-employee";
    }

    // CREATE EMPLOYEE ACTION
    @PostMapping("/employees/create")
    public String createEmployee(
            @RequestParam String name,
            @RequestParam int age,
            @RequestParam char designation,
            Model model) {

        // NAME VALIDATION
        if (!name.matches("[A-Za-z ]+") || name.chars().filter(c -> c == ' ').count() > 2) {
            model.addAttribute("error", "Name must contain only letters and max 2 spaces");
            return "create-employee";
        }

        // AGE VALIDATION
        if (age < 20 || age > 60) {
            model.addAttribute("error", "Age must be between 20 and 60");
            return "create-employee";
        }

        // DESIGNATION VALIDATION
        designation = Character.toUpperCase(designation);
        if (designation != 'P' && designation != 'M' && designation != 'T') {
            model.addAttribute("error", "Invalid designation");
            return "create-employee";
        }

        service.createEmployee(name, age, designation);
        return "redirect:/home";
    }

    // DISPLAY EMPLOYEES
    @GetMapping("/employees/list")
    public String listEmployees(Model model) {
        model.addAttribute("employees", service.getAll());
        return "display-employees";
    }

    // RAISE SALARY PAGE
    @GetMapping("/employees/raise")
    public String raisePage() {
        return "raise-salary";
    }

    // RAISE SALARY ACTION
    @PostMapping("/employees/raise")
    public String raiseSalary(
            @RequestParam String name,
            @RequestParam int percentage,
            Model model) {

        Optional<Employee> empOpt = service.findByName(name);

        if (empOpt.isEmpty()) {
            model.addAttribute("error", "Employee not found");
            return "raise-salary";
        }

        if (percentage < 1 || percentage > 10) {
            model.addAttribute("error", "Percentage must be between 1 and 10");
            return "raise-salary";
        }

        service.raiseSalary(empOpt.get(), percentage);
        model.addAttribute("success", "Salary updated successfully");
        return "raise-salary";
    }
}