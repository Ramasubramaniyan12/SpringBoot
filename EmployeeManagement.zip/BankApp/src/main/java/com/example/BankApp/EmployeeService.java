package com.example.BankApp;

import java.util.Optional;

import org.springframework.stereotype.Service;


@Service
public class EmployeeService {

    private final EmployeeRepository repository;

    // Constructor Injection (DI)
    public EmployeeService(EmployeeRepository repository) {
        this.repository = repository;
    }

    // CREATE EMPLOYEE
    public Employee createEmployee(String name, int age, char designation) {

        double salary;

        switch (designation) {
            case 'P':
                salary = 20000;
                break;
            case 'M':
                salary = 25000;
                break;
            case 'T':
                salary = 15000;
                break;
            default:
                throw new IllegalArgumentException("Invalid designation");
        }

        Employee emp = new Employee(name, age, designation, salary);
        return repository.save(emp);
    }

    // FIND EMPLOYEE BY NAME (case-insensitive)
    public Optional<Employee> findByName(String name) {
        return repository.findByNameIgnoreCase(name);
    }

    // RAISE SALARY
    public Employee raiseSalary(Employee employee, int percentage) {

        double increment = employee.getSalary() * percentage / 100;
        employee.setSalary(employee.getSalary() + increment);

        return repository.save(employee);
    }

    // GET ALL EMPLOYEES
    public Iterable<Employee> getAll() {
        return repository.findAll();
    }
}