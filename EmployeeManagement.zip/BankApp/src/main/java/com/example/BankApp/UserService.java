package com.example.BankApp;

import org.springframework.stereotype.Service;

@Service
public class UserService {

    private final UserRepository repo;

    public UserService(UserRepository repo) {
        this.repo = repo;
    }

    public void signup(String username, String password) {
        repo.save(new AppUser(username, password));
    }

    public boolean login(String username, String password) {
        return repo.findByUsername(username)
                   .map(u -> u.getPassword().equals(password))
                   .orElse(false);
    }
}