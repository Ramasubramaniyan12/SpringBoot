package com.example.BankApp;

public class CreateEmployeeRequest {
    public String name;
    public int age;
    public char designation;
}