package com.example.BankApp;

public class RaiseSalaryRequest {
    public int percentage;
}
