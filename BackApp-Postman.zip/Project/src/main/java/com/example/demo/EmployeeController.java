package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/employee")
public class EmployeeController {

    @Autowired
    EmployeeRepository repo;

    @PostMapping("/create")
    public Employee create(@RequestBody Employee emp) {

        if (emp.getAge() < 20 || emp.getAge() > 60) {
            throw new RuntimeException("Invalid age");
        }

        if (emp.getDesignation().equalsIgnoreCase("P")) {
            emp.setDesignation("Programmer");
            emp.setSalary(20000);
        } else if (emp.getDesignation().equalsIgnoreCase("M")) {
            emp.setDesignation("Manager");
            emp.setSalary(25000);
        } else if (emp.getDesignation().equalsIgnoreCase("T")) {
            emp.setDesignation("Tester");
            emp.setSalary(15000);
        } else {
            throw new RuntimeException("Invalid designation");
        }

        return repo.save(emp);
    }

    @GetMapping("/all")
    public List<Employee> display() {
        return repo.findAll();
    }

    @PutMapping("/raise/{name}/{percent}")
    public Employee raiseSalary(@PathVariable String name,
                                @PathVariable double percent) {

        if (percent < 1 || percent > 10) {
            throw new RuntimeException("Invalid percentage");
        }

        Employee emp = repo.findByName(name);
        if (emp == null) {
            throw new RuntimeException("Employee not found");
        }

        double newSalary = emp.getSalary() + (emp.getSalary() * percent / 100);
        emp.setSalary(newSalary);

        return repo.save(emp);
    }
}